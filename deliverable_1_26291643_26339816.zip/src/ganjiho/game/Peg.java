package ganjiho.game;

public abstract class Peg 
{
	public abstract String toString();
}
