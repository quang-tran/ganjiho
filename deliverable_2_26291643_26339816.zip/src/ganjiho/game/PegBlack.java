package ganjiho.game;

public class PegBlack extends Peg 
{
	public String toString() 
	{
		return "B";
	}
}
