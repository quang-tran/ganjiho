package ganjiho.game;


public class PegWhite extends Peg 
{
	public String toString() 
	{
		return "W";
	}
}
