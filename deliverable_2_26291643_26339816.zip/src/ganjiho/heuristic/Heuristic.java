package ganjiho.heuristic;

import ganjiho.game.Board;

public interface Heuristic 
{
	public int calculate(Board b);
}
